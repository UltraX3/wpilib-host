// Copyright (c) National Instruments 2008.  All Rights Reserved.
// Do Not Edit... this file is generated!

#ifndef __nFRC_2017_17_0_2_nInterfaceGlobals_h__
#define __nFRC_2017_17_0_2_nInterfaceGlobals_h__

namespace nFPGA
{
namespace nFRC_2017_17_0_2
{
   extern unsigned int g_currentTargetClass;
}
}

#endif // __nFRC_2017_17_0_2_nInterfaceGlobals_h__
